
import java.util.Scanner;

public class Usuarios extends Boleta{
    
    Usuarios(int precioNorte, int precioOccidental, int precioOriental, int precioSur){
        
        Boleta boleta = new Boleta();

        boleta.getPrecioBoletaNorte();
        boleta.getPrecioBoletaOccidental();
        boleta.getPrecioBoletaOriental();
        boleta.getPrecioBoletaSur();
    }

    public static void main(String args[]) {
        Boleta boleta = new Boleta();
        Taquilla taquilla = new Taquilla();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el Nombre completo:");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese su numero de cédula:");
        int cedula = Integer.parseInt(scanner.nextLine());

        System.out.println("Ingrese su numero de telefono:");
        int telefono = Integer.parseInt(scanner.nextLine());

        System.out.println("Su usuario ha sido creado con exito");

        System.out.println("============================================");

        System.out.println("Qué boleta desea adquirir?");

        System.out.println("Valor de boletas: " + "- Norte "+ boleta.getPrecioBoletaNorte() + "- Sur "+boleta.getPrecioBoletaOccidental()+
                    "- Oriental "+boleta.precioOriental+" - Sur "+boleta.getPrecioBoletaSur());


                    System.out.println("La cantidad de boletas vendidas fueron : " + taquilla.conteoTotal());

                    System.out.println("La ganancia de ventas fueron en total: " + boleta.ventaTotal());
    }

}

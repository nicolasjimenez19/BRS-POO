
public class Boleta extends Estadio{
    int precioBoleta;
    int localidadBoleta;
    int precioNorte = 15000;
    int precioSur = 10000;
    int precioOriental = 50000;
    int precioOccidental = 80000;

    Boleta(int getCapacidadTotal){
        Estadio estadio = new Estadio();

        estadio.getCapacidadTotal(getCapacidadTotal, getCapacidadTotal, getCapacidadTotal, getCapacidadTotal);
    }

    Boleta(){

    }

    public int getPrecioBoletaNorte() {
        return precioNorte;
    }

    public int getPrecioBoletaSur() {
        return precioSur;
    }

    public int getPrecioBoletaOccidental() {
        return precioOccidental;
    }

    public int getPrecioBoletaOriental() {
        return precioOriental;
    }

    public int getLocalidadBoleta(){
        return localidadBoleta;
    }

    public int getTotal(){
        return getCapacidadTotal(getCapacidadLocalidadNorte(), getCapacidadLocalidadOccidental(), getCapacidadLocalidadOriental(), 
                    getCapacidadLocalidadSur());
    }
    
    public int ventaTotal(){
        return (getCapacidadLocalidadNorte() * getPrecioBoletaNorte()) + (getCapacidadLocalidadOccidental() * getPrecioBoletaOccidental()) +
        (getCapacidadLocalidadOriental() * getPrecioBoletaOriental()) + (getCapacidadLocalidadSur() * getPrecioBoletaSur());
    }

}


public class Taquilla extends Estadio{

    Boleta boleta = new Boleta();

    int id;  
    boolean disponible;
    double precio;
   
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    
    public boolean isDisponible() {
        return disponible;
    }
    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public double getPrecio() {
        return precio;
    }
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean estaDisponible(){
        return disponible;
    }

    public void reservar() {
        disponible = false;
    }

    public void liberar(){
        disponible = true;
    }

    public int conteoTotal(){
        return boleta.getTotal();
    }

    public int gananciaTotal(){
        return boleta.ventaTotal();
    }

}



import java.util.ArrayList;

public class Estadio {

    String localidad;
    int capacidadTotal;
    int capacidadLocalidad;
    String ubiEstadio;
    ArrayList<String> nombreEstadio;

    Estadio(){
        
    }

    Estadio(String localidad, int capacidadTotal, int capacidadLocalidad, String ubiEstadio) {
        this.localidad = localidad;
        this.capacidadTotal = capacidadTotal;
        this.capacidadLocalidad = capacidadLocalidad;
        this.ubiEstadio = ubiEstadio;
    }

    public int getCapacidadLocalidadNorte() {
        return capacidadLocalidad = 6;
    }

    public int getCapacidadLocalidadSur() {
        return capacidadLocalidad = 8;
    }

    public int getCapacidadLocalidadOccidental() {
        return capacidadLocalidad = 12;
    }

    public int getCapacidadLocalidadOriental() {
        return capacidadLocalidad = 45;
    }

    public int getCapacidadTotal(int getCapacidadLocalidadNorte, int getCapacidadLocalidadSur,
            int getCapacidadLocalidadOccidental, int getCapacidadLocalidadOriental) {
                
        return getCapacidadLocalidadNorte + getCapacidadLocalidadSur + getCapacidadLocalidadOccidental
                + getCapacidadLocalidadOriental;
    }

    

}
